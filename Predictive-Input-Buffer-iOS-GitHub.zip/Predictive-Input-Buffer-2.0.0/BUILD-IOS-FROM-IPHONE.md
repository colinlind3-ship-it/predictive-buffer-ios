# Build the iOS version from an iPhone

This project is configured to attempt an iOS build using GitHub Actions on a macOS runner.

## Build steps

1. On your iPhone, open GitHub in Safari and sign in.
2. Create a new public or private repository.
3. Upload the contents of this project folder to the repository, including the hidden `.github/workflows/build-ios.yml` file. If GitHub's mobile uploader omits hidden folders, use GitHub's web interface in Safari with **Request Desktop Website** or add the workflow through the repository editor.
4. Commit the files to the default branch.
5. Open the repository's **Actions** tab. If prompted, enable Actions.
6. Select **Build Geode Mod (iOS)** and tap **Run workflow**.
7. Open the workflow run after it finishes. If successful, download the artifact named `geode-build-ios`. Extract it in the iOS Files app to find the `.geode` file.

## Important

- This is an attempted source port, not a verified build. The GitHub Actions result is the source of truth; a compiler error means more code changes are needed.
- The Windows-only live console is disabled on iOS; use Geode's logs instead.
- Default F6–F10 keybinds require a keyboard/controller mapping and may not be practical on a touchscreen. Settings can still be changed through the mod's settings UI if the mod builds and loads.
- Confirm that your installed iOS Geode build supports mods compiled for the same loader line. If the build fails, share the failed Actions log so the compile errors can be fixed.
